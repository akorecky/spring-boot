package com.example.demo;

public interface HelloService {
  void greet();
}
